https://dreamacro.github.io/clash/zh_CN/configuration/outbound.html#shadowsocks



export http_proxy="socks5://127.0.0.1:7890"
export https_proxy="socks5://127.0.0.1:7890"


export http_proxy=http://127.0.0.1:7890
export https_proxy=http://127.0.0.1:7890


export http_proxy=http://brd-customer-hl_a6201b53-zone-isp:8g7u9hhkpuhv@brd.superproxy.io:22225
export https_proxy=http://brd-customer-hl_a6201b53-zone-isp:8g7u9hhkpuhv@brd.superproxy.io:22225


export http_proxy=http://BQ3wWZWe3A:LlRnmzlEG1@google.xiahaijiao.eu.org:10095
export https_proxy=http://BQ3wWZWe3A:LlRnmzlEG1@google.xiahaijiao.eu.org:10095


unset http_proxy
unset https_proxy
unset HTTP_PROXY

systemctl daemon-reload
systemctl enable clash
systemctl start clash
systemctl status clash
systemctl stop clash
systemctl restart clash

journalctl -xe
 journalctl -xfu clash


curl https://www.google.com
curl http://ipinfo.io


---------docker 配置代理   start -----------

 1029  systemctl status docker
 1030  vi /usr/lib/systemd/system/docker.service

 #添加如下       ------------- begin

#[Service]
Environment="HTTP_PROXY=http://127.0.0.1:7890"
Environment="HTTPS_PROXY=http://127.0.0.1:7890"

#取消代理
Environment="NO_PROXY=localhost,127.0.0.1"


# -------------- end


 1031  systemctl daemon-reload
 1032  systemctl restart docker
 1033  systemctl show --property=Environment docker
 1034  docker pull busybox


----------docker  配置代理 end --------------
