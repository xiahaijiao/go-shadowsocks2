
#wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/clash/Country.mmdb
#wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/clash/clash-linux-amd64-v1.17.0
#mv Country.mmdb clash/Country.mmdb

cp -fr clash /etc/
cp clash-linux-amd64-v1.17.0 /usr/bin/clash
chmod +x /usr/bin/clash


# /usr/bin/clash -d /etc/clash

cat << eof > /etc/systemd/system/clash.service
[Unit]
Description=Clash 守护进程, Go 语言实现的基于规则的代理.
After=network-online.target

[Service]
Type=simple
Restart=always
ExecStart=/usr/bin/clash -d /etc/clash

[Install]
WantedBy=multi-user.target
eof



systemctl daemon-reload
#systemctl enable clash
systemctl start clash
systemctl status clash
journalctl -xe

