rootProject.extra.apply {
    set("androidPlugin", "com.android.tools.build:gradle:7.4.1")
    set("kotlinVersion", "1.8.10")
}

repositories {
    google()
    jcenter()
}
