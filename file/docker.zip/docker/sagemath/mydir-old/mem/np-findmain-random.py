
#!/usr/bin/env sage
import sys
import time

from sage.all import *
import random

import subprocess
script2_path = '/home/sage/mydir/np-find-single.py'
script2_path = '/home/sage/mydir/mem/np-find-single.py'
#script2_path = './np-find-single.py'




start_num = 107361793816595537
start_num = 123230573852164273674364426950
start_num = 123230573852164273674376029967
start_num = 1000000000000000
start_num = 100000000000
start_num = 40473193
start_num = 43171783


count = 10000000
count = 100000

# start_num = 13
# count = 100


end_num = start_num + count
while 1 :
    # cal(start_num,end_num)

    random_int = random.randint(1000000000000000, 10000000000000000)
    print(random_int)
    start_num = random_int


    # start_num = end_num
    end_num = start_num + count
    # arg1 = 'hello'
    # arg2 = 'world'

    arg1 = str(start_num)
    arg2 = str(end_num)

    result = subprocess.run(['python', script2_path, arg1, arg2], capture_output=True, text=True)

    output = result.stdout.strip()
    print('Output from script2.py:', output)



    print("-----------------start-------------------------",start_num)
    time.sleep(3)
#    break
