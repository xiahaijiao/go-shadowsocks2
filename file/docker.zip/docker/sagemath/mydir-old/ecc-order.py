
#!/usr/bin/env sage
import sys
import time

from sage.all import *

start_num = 13
count = 1000
count = 31069

# start_num = 31069
# count = 1000000

start_num = 8589247
start_num = 10242637
count = 10000000
end_num = start_num + count

def cal(start_num,end_num):
    index_num = 0
    while start_num < end_num:
        p = start_num
        if is_prime(p):
            n = EllipticCurve(GF(p), [0, 7]).order()
            if is_prime(n):
                pass
                p_1 = factor(p - 1)
                n_1 = factor(n - 1)
                print("p=", p, ",n=", n, "; p-1=", p_1, " \t \t,n_1=", n_1)

        start_num = start_num + 1

    pass

start_num = 10242637
count = 10000000

# start_num = 13
# count = 100


end_num = start_num + count
while 1 :
    cal(start_num,end_num)
    start_num = end_num
    end_num = start_num + count
    print("-----------------start-------------------------",start_num)
    time.sleep(3)

