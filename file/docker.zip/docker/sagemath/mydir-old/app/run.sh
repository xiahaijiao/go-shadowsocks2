nohup ./main.sh app.py > ./log  2>&1 &
