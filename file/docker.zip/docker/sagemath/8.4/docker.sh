mkdir -p mydir
chmod 777 -R mydir
#docker run -itd --name sagemath8.4 --restart always -p 10090:8888 -v ./mydir:/home/sage/mydir sagemath/sagemath:8.4 bash
#docker run -itd --name sagemath8.4 --restart always -p 10090:8888 -v ./mydir:/home/sage/mydir xiahaijiao/h-shgroup:sagemath-9.7 bash
#
#
#docker run -itd --name sagemath8.4 --restart always -p 10090:8888  xiahaijiao/h-shgroup:sagemath-9.7 /home/sage/main2.sh
#
#
#
#docker run -itd --name sagemath8.4 --restart always -p 10090:8888 -v ./mydir:/home/sage/mydir2 xiahaijiao/h-shgroup:sagemath-9.7 /home/sage/main2.sh
#
#
#
#
#docker run -itd --name sagemath8.4 --restart always -p 10090:8888 -p 80:80 xiahaijiao/h-shgroup:sagemath-9.7-post /home/sage/main2.sh
#


docker stop sagemath8.4
docker rm sagemath8.4
mkdir -p mydir
chmod 777 -R mydir
docker run -itd --name sagemath8.4 --restart always -v ./mydir:/home/sage/mydir  -p 10090:8888 -p 80:80 xiahaijiao/h-shgroup:sagemath-9.7-post /home/sage/main2.sh


