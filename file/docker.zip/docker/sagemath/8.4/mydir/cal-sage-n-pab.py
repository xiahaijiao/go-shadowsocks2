# !/usr/bin/env sage
import sys
import time

from sage.all import *
import random

from flask import Flask, request, jsonify
import ast

debug=false

def cal_n_abp(a,b,p):    
    n = EllipticCurve(GF(p), [a, b]).order()
    return n
    pass
# a=0
# b=7
# p=43
# res=cal_n_abp(a,b,p)
# print(res)


# a=350
# k=2
# p=13
a=sys.argv[1]
b=sys.argv[2]
p=sys.argv[3]

a=int(a)
b=int(b)
p=int(p)

res=cal_n_abp(a,b,p)
print(res)

