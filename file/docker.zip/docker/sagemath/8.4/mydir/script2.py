import sys

# 接收传入的参数
arg1 = sys.argv[1]
arg2 = sys.argv[2]

# 对参数进行处理，这里简单示例为拼接字符串
result = arg1 + ' ' + arg2

# 返回处理结果
print(result)

