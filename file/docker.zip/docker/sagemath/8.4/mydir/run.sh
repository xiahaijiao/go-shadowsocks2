app=$1
mydate=`date +%F`
nohup ./main.sh $app >> ./log-$app-$mydate.log  2>&1 &