# !/usr/bin/env sage
import sys
import time

from sage.all import *
import random

from flask import Flask, request, jsonify
import ast
import subprocess

debug=false


app = Flask(__name__)



def compute_single_primitive(k, p):
    my_ring = GF(p)
    my_a = my_ring(1)
    my_x = my_a.nth_root(k)
    marray = []
    for i in range(0, k):
        temp = power_mod(my_x, i, p)
        marray.append(temp)
    #     print(marray)
    return marray
    pass


def compute_single_p(a, k, p):
    a=int(a)
    k=int(k)
    p=int(p)
    print(f'---------{a,k,p},{type(p)}')
    my_ring2 = GF(13)
    print(my_ring2)
    my_ring = GF(p)
    print(f'---------{my_ring}')

    my_a = my_ring(a)
    my_x = my_a.nth_root(k)
    primitive_array = compute_single_primitive(k, p)
    marray = []
    for item in primitive_array:
        temp = item * my_x % p
        temp = int(temp)
        marray.append(temp)
        pass
    marray.sort()
    return marray


# a=350
# k=2
# p=13
# res=compute_single_p(a, k, p)
# print(res)






@app.route('/api/cal_nkp_roots', methods=['POST'])
def cal_nkp_roots():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
        a = req_data['a']
        k = req_data['k']
        p = req_data['p']
        print(f'{req_data}')
        script2_path = '/home/sage/mydir/cal-roots-akp.py'

        # 传入的参数
        # arg1 = "1"
        # arg2 = "2"
        # arg3 = "13"

        arg1 = str(a)
        arg2 = str(k)
        arg3 = str(p)
        # 使用subprocess模块调用Python脚本，并传入参数
        result = subprocess.run(['python', script2_path, arg1, arg2,arg3], capture_output=True, text=True)

        # 获取脚本执行结果
        output = result.stdout.strip()
        print('Output from script2.py:', output)
        res=output
        print(f'res:{res}')

        return jsonify({'response': f'Received message: {req_data} ,cal_nkp_roots, res=[p_array,a_array,root_array]',
                        'res': f'{res}'})

    return jsonify({'error': 'Message not found'}), 400


if __name__ == '__main__':
    # app.run(debug=True)
    #    app.run(host='0.0.0.0', debug=True)
    my_ring2 = GF(13)
    print("------- my_ring2 ",my_ring2)


    a=350
    k=2
    p=13
    print(type(a),type(k),type(p))

    res=compute_single_p(a, k, p)
    print(res)

    app.run(debug=True, host='0.0.0.0', port=8888)

