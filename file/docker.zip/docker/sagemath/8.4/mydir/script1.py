import subprocess

# 要执行的Python脚本的文件路径
script2_path = '/home/sage/mydir/script2.py'

# 传入的参数
arg1 = 'hello'
arg2 = 'world'

# 使用subprocess模块调用Python脚本，并传入参数
result = subprocess.run(['python', script2_path, arg1, arg2], capture_output=True, text=True)

# 获取脚本执行结果
output = result.stdout.strip()
print('Output from script2.py:', output)

