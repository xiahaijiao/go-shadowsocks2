
#!/usr/bin/env sage
import sys
import time

from sage.all import *
import random
