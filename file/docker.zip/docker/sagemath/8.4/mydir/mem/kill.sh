ps -ef|grep -v grep | grep np 
ps -ef|grep -v grep | grep np |awk '{print $2}'
ps -ef|grep -v grep | grep np |awk '{print $2}'|xargs -i kill -9 {}

