
#!/usr/bin/env sage
import sys
import time

from sage.all import *
import random



start_num = 8589247
start_num = 10242637
count = 10000000
end_num = start_num + count

def cal(start_num,end_num):
    file_path = '/home/sage/mydir/mem/data.txt'
    file_content = 'Hello, this is some content that will be written to the file.'


    with open(file_path, 'a') as file:
        # file.write(file_content)
        pass


        index_num = 0
        while start_num < end_num:
            p = start_num
            if is_prime(p):
                n = EllipticCurve(GF(p), [0, 7]).order()
                if is_prime(n):
                    print("p=", p, ",n=", n)
                    file.write(f'p={p},n={n}\n')
                    if p==n:
                        file.write(f'-------- success p=n p={p},n={n}\n')
                        print("p=", p, ",n=", n)
                        print("-------------- success p=n ",p,n)
    #                    break
                    pass
    #                 p_1 = factor(p - 1)
    #                 n_1 = factor(n - 1)
    #                 print("p=", p, ",n=", n, "; p-1=", p_1, " \t \t,n_1=", n_1)

            start_num = start_num + 1
        file.close()

    pass
arg1 = sys.argv[1]
arg2 = sys.argv[2]
start_num=int(arg1)
end_num=int(arg2)
cal(start_num,end_num)