# !/usr/bin/env sage
import sys
import time

from sage.all import *
import random

from flask import Flask, request, jsonify
import ast
import subprocess

debug=false


app = Flask(__name__)


@app.route('/api/post_data', methods=['POST'])
def post_data():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
        a = req_data['a']
        b = req_data['b']
        p = req_data['p']

        res = {'a': a,
               'b': b,
               'p': p,
               'message': message}
        print(a, b, p, message)
        print(res)
        return jsonify({'response': f'Received message: {message},{res}'})

    return jsonify({'error': 'Message not found'}), 400


def cal_small_p_points(a, b, p):
    mlist = []
    # 遍历x坐标范围内的所有值
    x_values = range(0, p)
    for x in x_values:
        y_squared = (x ** 3 + a * x + b) % p
        # 检查y^2是否为完全平方数，如果是则打印该点
        for y in range(p):
            if (y ** 2) % p == y_squared:
                #             print(f'({x}, {y})')
                #             print(f'({x}, {-y % p})')
                item1 = (x, y)
                item2 = (x, -y % p)
                mlist.append(item1)
                mlist.append(item2)
                # break
    mlist = list(set(mlist))
    mlist.sort()
    print(mlist)
    print(len(mlist))
    return mlist

    pass


@app.route('/api/cal_samllp_point', methods=['POST'])
def cal_samllp_point():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
        a = req_data['a']
        b = req_data['b']
        p = req_data['p']
        print(f'req_data:{req_data}')
        # a = 0
        # b = 7
        # # p=570457909
        # p=559
        # # p=13
        res = cal_small_p_points(a, b, p)
        print(f'res:{res}')

        return jsonify({'response': f'Received message: {req_data},cal_samllp_point ,{len(res)}',
                        'res': res})

    return jsonify({'error': 'Message not found'}), 400


# 非素数求解
def cal_double(x, y, p, A, B):
    # print(f'cal_double ,{x},{y},{p},{A},{B}')
    # m=3x^2+A /2*y
    # x3= m^2 -2*x ,y3=m(x1-x3) -y1
    if x == "inf" or y == "inf":
        return ("inf", "inf")
    pass

    status = 2 * y % p
    status = gcd(2 * y, p)
    # print(status)
    if status != 1:
        return ("inf", "inf")
        pass
    # print(f'------{x},{A},{p}')
    # temp=(3 * x ^ 2 + A) % p
    # temp2=(3*(x**2) + A) % p
    # temp3=(3*(x^2) + A) % p
    # temp4=(3*x^2 + A) % p
    # temp5=(3*x**2 + A) % p

    m1 = (3 * x**2 + A) % p
    # print(f'-------{temp2},{temp3},{temp4},{temp5},{temp},{m1}')
    m2 = inverse_mod(2 * y, p)
    m = m1 * m2 % p
    x3 = (m**2 - 2 * x) % p
    y3 = (m * (x - x3) - y) % p
    # print(f'{m1},{m2},{m},{x3},{y3}')
    return (x3, y3)
    pass


def cal_add(x1, y1, x2, y2, p, A, B):
    # m=(y2-y1)/(x2-x1)
    # x3=m^2-x1-x2,  y3=m(x1-x3)-y1
    if x2 == 0 and y2 == 0:
        return (x1, y1)
        pass
    if x1 == 0 and y1 == 0:
        return (x2, y2)
    pass

    if x1 == x2 and y1 == y2:
        return cal_double(x1, y1, p, A, B)
        pass
    if x1 == x2 and y1 != y2:
        return ("inf", "inf")
        pass

    if x1 == "inf" or x2 == "inf":
        return ("inf", "inf")
        pass

    m1 = (y2 - y1) % p
    m2 = (x2 - x1) % p
    status = gcd(m2, p)
    #     print(status)
    if status != 1:
        return ("inf", "inf")
        pass
    m3 = inverse_mod(m2, p)
    m = m1 * m3 % p
    x3 = (m**2 - x1 - x2) % p
    y3 = (m * (x1 - x3) - y1) % p
    return (x3, y3)

    pass


def integer_to_binary_powers(n):
    binary_representation = bin(n)[2:]  # 获取二进制表示并去除前缀"0b"

    powers_of_two = [int(bit) * 2 ** i for i, bit in enumerate(reversed(binary_representation))]

    return powers_of_two


def cal_multiply(x, y, k, p, A, B):
    powers_representation = integer_to_binary_powers(k)
    if debug:
        print(k, powers_representation)
        pass
    #     print(k,powers_representation)
    # print(f'cal_multiply,{x},{y},{k},{p},{A},{B}')
    base_point = (0, 0)
    k_base_point = 0
    for powers in powers_representation:
        if powers == 0:
            if debug:
                print("\n")
                print(powers, "0 case, 跳过")
                pass

            #             print("\n")
            #             print(powers, "0 case, 跳过")
            continue
            pass
        elif powers == 1:
            if debug:
                print("\n")
                print(powers, " 1 case, add point")
                pass

            #             print("\n")
            #             print(powers," 1 case, add point")
            base_point = cal_add(base_point[0], base_point[1], x, y, p, A, B)
            k_base_point = k_base_point + 1
            if debug:
                print(k_base_point, base_point)
                pass

            #             print(k_base_point,base_point)
            pass
        else:
            if debug:
                print("\n")
                print(powers, " 2 case, 2的倍数，指数，调用double")
                pass

            #             print("\n")
            #             print(powers," 2 case, 2的倍数，指数，调用double")
            power = log(powers, 2)
            if debug:
                print(power)
                pass
            #             print(power)
            n = power
            base = 1
            power_point = (x, y)
            for i in range(1, n + 1):

                base = base * 2

                power_point = cal_double(power_point[0], power_point[1], p, A, B)
                if debug:
                    print(i, base, power_point)
                    pass

                #                 print(i,base,power_point)
                pass

            pass
            k_base_point = k_base_point + base
            if debug:
                print(base_point, power_point)
                pass
            #             print(base_point,power_point)
            base_point = cal_add(base_point[0], base_point[1], power_point[0], power_point[1], p, A, B)
            if debug:
                print(k_base_point, base_point)
                pass
        #             print(k_base_point,base_point)
        pass

    pass
    #     power_point

    if debug:
        print(k, base_point)
        pass

    return base_point
    pass


def cal_all(point1, p, n, A, B):
    # A=0
    # B=7
    # print(f'call_all ,{p},{n},{A},{B}')
    # n=1801
    # p=2623
    # point1=(7,566)
    mlist = []
    for i in range(1, n):
        #     print(i)
        k = i
        point3 = cal_multiply(point1[0], point1[1], k, p, A, B)

        # point3 = cal_double(11,5)
        #         print(k,point3)
        item = (point3[0], point3[1], k)
        mlist.append(item)
        pass
    #     print(mlist)
    return mlist
    pass


def custom_sort(item):
    if item[0] == 'inf':
        return float('inf')
    else:
        return item[0]


def custom_sort_y(item):
    if item[1] == 'inf':
        return float('inf')
    else:
        return item[1]


def cal_x(array):
    mlist = []
    for item in array:
        x = item[0]

        if x == 'inf':
            continue
        mlist.append(x)
    mlist = list(set(mlist))
    mlist.sort()
    # print(mlist)
    return mlist


# y^2=x^3+A*x + B

# debug = true



@app.route('/api/cal_all_point', methods=['POST'])
def cal_all_point():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
        # a=req_data['a']
        # b=req_data['b']
        # p=req_data['p']

        # my_tuple = ast.literal_eval(my_string)

        A=req_data['a']
        B=req_data['b']
        p=req_data['p']
        n=req_data['n']
        point=req_data['point']
        point1=ast.literal_eval(point)

        print(f'req_data:{req_data}')
              
        print(f'{A,B,p,n,point,point1}')

        # A = 0
        # B = 7

        # # p = 13
        # # n = 7
        # # point1 = (7, 8)

        # p=559
        # n=217
        # point1=(7,437)

        # p=43
        # n=31
        # point1=(7,7)

        # single
        # point3=cal_multiply(point1[0],point1[1],k)
        # print(point3)
        # all
        mlist = cal_all(point1, p, n, A, B)
        k_points = mlist
        print(mlist)
        sorted_data = sorted(mlist, key=custom_sort)
        print(sorted_data)
        x_points = sorted_data
        sorted_datay = sorted(mlist, key=custom_sort_y)
        print(sorted_datay)
        y_points = sorted_datay
        xy_points = cal_x(mlist)


        # single
        # point3=cal_multiply(point1[0],point1[1],k)
        # print(point3)


        res = {'k_points': k_points,
               'x_points': x_points,
               'y_points': y_points,
               'xy_points': xy_points}

        print(f'res:{res}')
        return jsonify({'response': f'Received message: {req_data}, cal_all_point',
                        'res': f'{res}'})

    return jsonify({'error': 'Message not found'}), 400


@app.route('/api/cal_single_point', methods=['POST'])
def cal_single_point():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
   


        A=req_data['a']
        B=req_data['b']
        p=req_data['p']
        k=req_data['k']
        point=req_data['point']
        point1=ast.literal_eval(point)

        print(f'req_data:{req_data}')
              
        print(f'{A,B,p,n,point,point1}')

        point3=cal_multiply(point1[0],point1[1],k,p,A,B)
        print(point3)
        
        res = {'point3': point3}

        print(f'res:{res}')
        return jsonify({'response': f'Received message: {req_data}, cal_single_point',
                        'res': f'{res}'})


    return jsonify({'error': 'Message not found'}), 400


@app.route('/api/cal_crt', methods=['POST'])
def cal_crt():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']

        # a_array_str=req_data['a_array']
        # p_array_str=req_data['p_array']

        a_array = req_data['a_array']
        p_array = req_data['p_array']

        print(f'req_data:{req_data}')

        # p_array=[13, 43, 61, 31069]
        # a_array=[5, 7, 17, 10684]
        res = crt(a_array, p_array)
        print(f'res:{res}')

        return jsonify({'response': f'Received message: {req_data} ,cal_crt',
                        'res': f'{res}'})

    return jsonify({'error': 'Message not found'}), 400


# 模为大合数，高次剩余

def compute_chinese(p_array, a_arrays):
    marray = []
    for combinations in a_arrays:
        combinations = list(combinations)
        result = crt(combinations, p_array)
        marray.append(result)
        pass
    #     print(marray)
    marray.sort()
    #     print(marray)
    return marray

    pass


def compute_single_primitive(k, p):
    my_ring = GF(p)
    my_a = my_ring(1)
    my_x = my_a.nth_root(k)
    marray = []
    for i in range(0, k):
        temp = power_mod(my_x, i, p)
        marray.append(temp)
    #     print(marray)
    return marray
    pass


def compute_single_p(a, k, p):
    a=int(a)
    k=int(k)
    p=int(p)
    print(f'---------{a,k,p},{type(p)}')
    my_ring2 = GF(13)
    print(my_ring2)
    my_ring = GF(p)
    print(f'---------{my_ring}')

    my_a = my_ring(a)
    my_x = my_a.nth_root(k)
    primitive_array = compute_single_primitive(k, p)
    marray = []
    for item in primitive_array:
        temp = item * my_x % p
        temp = int(temp)
        marray.append(temp)
        pass
    marray.sort()
    return marray


def cal_combinations(arrays):
    from itertools import product

    # 给定数组列表
    #     arrays = [[5, 8], [7, 36]]
    #     arrays=[[5, 8], [7, 36], [17, 44], [10684, 20385]]

    # 生成所有组合
    combinations = list(product(*arrays))

    #     print(combinations)

    return combinations
    pass


def cal_mulitpy_p(a, k, p):
    factors = factor(p)

    # 将素因子数组转换为列表
    factors_list = list(factors)

    # 打印结果
    print(factors_list)
    p_array = []
    a_arrays = []
    for item in factors_list:
        p1 = item[0]
        k1 = item[1]
        if k1 >= 2:
            print("error", factors_list)
            return -1
            break
        res_a = compute_single_p(a, k, p1)

        a_arrays.append(res_a)
        print(p1, res_a)
        p_array.append(p1)
    p_array.sort()
    combinations = cal_combinations(a_arrays)
    print(p_array)
    print(a_arrays)
    print(combinations)

    print(p)
    res_roots = compute_chinese(p_array, combinations)
    print(res_roots)
    return (p_array, a_arrays, res_roots)

    pass


@app.route('/api/cal_nkp_roots', methods=['POST'])
def cal_nkp_roots():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
        a = req_data['a']
        k = req_data['k']
        p = req_data['p']
        print(f'req_data:{req_data}')

        script2_path = '/home/sage/mydir/cal-roots-akp.py'

        # 传入的参数
        # arg1 = "1"
        # arg2 = "2"
        # arg3 = "13"

        arg1 = str(a)
        arg2 = str(k)
        arg3 = str(p)
        # 使用subprocess模块调用Python脚本，并传入参数
        result = subprocess.run(['python', script2_path, arg1, arg2,arg3], capture_output=True, text=True)

        # 获取脚本执行结果
        output = result.stdout.strip()
        print('Output from script2.py:', output)
        res=output
        print(f'res:{res}')



        return jsonify({'response': f'Received message: {req_data} ,cal_nkp_roots, res=[p_array,a_array,root_array]',
                        'res': f'{res}'})

    return jsonify({'error': 'Message not found'}), 400

def cal_n_abp_sage(a,b,p):    
    n = EllipticCurve(GF(p), [a, b]).order()
    return n
    pass

@app.route('/api/cal_n_abp', methods=['POST'])
def cal_n_abp():
    req_data = request.get_json()

    if 'message' in req_data:
        message = req_data['message']
        a = req_data['a']
        b = req_data['b']
        p = req_data['p']
        print(f'req_data:{req_data}')

        script2_path = '/home/sage/mydir/cal-sage-n-pab.py'

        # 传入的参数
        # arg1 = "1"
        # arg2 = "2"
        # arg3 = "13"
        # a=0
        # b=7
        # p=43
        # res=cal_n_abp_sage(a,b,p)
        # print(res)


        arg1 = str(a)
        arg2 = str(b)
        arg3 = str(p)
        # 使用subprocess模块调用Python脚本，并传入参数
        result = subprocess.run(['python', script2_path, arg1, arg2,arg3], capture_output=True, text=True)

        # 获取脚本执行结果
        output = result.stdout.strip()
        print('Output from script2.py:', output)
        res=output
        print(f'res:{res}')



        return jsonify({'response': f'Received message: {req_data} ,cal_n_abp, res=n',
                        'res': f'{res}'})

    return jsonify({'error': 'Message not found'}), 400




if __name__ == '__main__':
    # app.run(debug=True)
    #    app.run(host='0.0.0.0', debug=True)
    app.run(debug=True, host='0.0.0.0', port=8888)

