grep "p=n" log*
grep "start" log*
