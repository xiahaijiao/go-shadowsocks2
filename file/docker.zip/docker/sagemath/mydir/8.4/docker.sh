mkdir -p mydir
chmod 777 -R mydir
docker run -itd --name sagemath8.4 -p 10090:8888 -v ./mydir:/home/sage/mydir sagemath/sagemath:8.4 bash
