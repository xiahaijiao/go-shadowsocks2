/home/sage/sage/src/bin/sage-python $1
#/home/sage/sage/local/var/lib/sage/venv-python3.10.5/bin/python3 -u $1
