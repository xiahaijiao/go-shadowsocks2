docker stop aria2-ui
docker rm aria2-ui
img=xiahaijiao/h-shgroup:aria2-ui
#img=wahyd4/aria2-ui
dir=`pwd`/data
mkdir -p $dir
chmod 777 -R $dir
docker run -d --name aria2-ui -p 10095:80 -e ARIA2_EXTERNAL_PORT=10095 -v $dir:/data $img

