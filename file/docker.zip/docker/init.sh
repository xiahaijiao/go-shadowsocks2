#设置vim
cat << eof >> ~/.vimrc
set mouse-=a
set paste
set background=dark  " 如果您使用的是深色主题
colorscheme desert   " 更换主题，您可以选择其他颜色方案
eof
source ~/.vimrc

#设置bash
cat <<eof >> ~/.bashrc
alias ll='ls -l --color=auto'
alias grep='grep --color'
eof
source ~/.bashrc

#时间

date
cat << eof >> /etc/profile
TZ='Asia/Shanghai'; export TZ
eof
source /etc/profile
date

timedatectl set-timezone Asia/Shanghai
timedatectl status


#工具脚本
cat <<EOF >./ip.sh
 curl https://ip38.com |grep 的iP地址是
 curl https://ipinfo.io/
EOF
chmod +x ./ip.sh

cat <<EOF >./vnstat.sh
vnstat -d
EOF
chmod +x ./vnstat.sh

cat <<EOF >./hostname.sh
 hostnamectl set-hostname instance-taiwan
EOF
chmod +x ./hostname.sh

touch nginx hysteria v2ray-shadowsocks
# mvn 环境变量
#export MAVEN_HOME=/var/jenkins_home/apache-maven-3.9.0
#export PATH=${PATH}:${MAVEN_HOME}/bin