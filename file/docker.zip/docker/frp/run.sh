chmod +x frps
#nohup ./frps -c frps.ini > frps.log 2>&1 &

#server
nohup ./frps  -c frps.toml  > frps.log 2>&1 &

#client
# nohup ./frpc -c frpc.toml  > frpc.log 2>&1 &