
source ~/.bashrc

dir=`pwd`
cd /root/socket/
sh run.sh
cd /root/v2ray/bin
sh run.sh
cd $dir

index=1
while [ 1 ]
do
        date
        echo $index
	let index++
        sleep 86400

done



