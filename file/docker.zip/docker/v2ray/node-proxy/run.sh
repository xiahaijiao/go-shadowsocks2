docker run -d -p 10080:7860 --name my-running-proxy --restart always xiahaijiao/h-shgroup:node-proxy-v2
# vless://d342d11e-d424-4583-b36e-524ab1f0afa4@35.243.98.70:10080?encryption=none&security=none&fp=randomized&type=ws&path=%2F#default

