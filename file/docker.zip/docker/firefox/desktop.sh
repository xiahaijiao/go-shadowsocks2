docker run --name=desktp -itd -u root --shm-size=512m -p 10083:6901 -e VNC_PW=xiahaijiao xiahaijiao/h-shgroup:desktop



#https://hub.docker.com/r/kasmweb/desktop
#The container is now accessible via a browser : https://japan.xiahaijiao.eu.org:10083/

    #User : kasm_user
    #Password: xiahaijiao