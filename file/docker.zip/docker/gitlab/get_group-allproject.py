import requests

# 设置 GitLab API 的基本 URL 和私有访问令牌
base_url = 'https://gitlab.example.com/api/v4'
private_token = 'YOUR_PRIVATE_TOKEN'  # 替换为您的私有访问令牌
group_id = 'hongsheng'  # 替换为您的群组 ID 或路径



base_url = "http://gitlab.wahaha.com.cn:8090/api/v4"
private_token = "qqcbikFL1ALfWmyw6u-6"



# 构建请求头，包含私有访问令牌
headers = {'PRIVATE-TOKEN': private_token}

# 发送 GET 请求到 /groups/:id/projects 端点获取群组下所有项目
response = requests.get(f'{base_url}/groups/{group_id}/projects?page=1&per_page=100', headers=headers)
response = requests.get(f'{base_url}/groups/{group_id}/projects?page=2&per_page=100', headers=headers)
response = requests.get(f'{base_url}/groups/{group_id}/projects?page=3&per_page=100', headers=headers)


# 检查响应状态码
if response.status_code == 200:
    # 将响应转换为 JSON 格式并打印项目信息
    projects = response.json()
    # print(projects)
    for project in projects:
        print(f"ID: {project['id']}, Name: {project['name']}, URL: {project['http_url_to_repo']}")
else:
    print(f"Failed to retrieve projects. Status code: {response.status_code}")


# http_url_to_repo