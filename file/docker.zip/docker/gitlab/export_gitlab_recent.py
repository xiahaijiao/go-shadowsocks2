import requests

# 设置GitLab API的URL和访问令牌
GITLAB_URL = "https://gitlab.com/api/v4/projects"
ACCESS_TOKEN = "<your_access_token>"

GITLAB_URL = "https://gitlab.h-shgroup.com/api/v4/projects"
ACCESS_TOKEN = "jeZWf8guKK7YBEspYbt4"


# ?page={page}&per_page={per_page}

# 发送API请求
response = requests.get(
    GITLAB_URL,
    headers={"PRIVATE-TOKEN": ACCESS_TOKEN},
    # params={"order_by": "last_activity_at", "sort": "desc"}
    params={"order_by": "last_activity_at", "sort": "desc","page":1,"per_page":25}
)

# 检查请求是否成功
if response.status_code == 200:
    projects = response.json()
    # 处理并显示项目数据
    for project in projects:
        # print(f"Project Name: {project['name']}")
        # print(f"Description: {project['description']}")
        # print(f"Last Activity: {project['last_activity_at']}")
        # print()
        print(f"id: {project['id']}, path: \"{project['path']}\"                                ,Project Name: {project['name']},Description: {project['description']}，Last Activity: {project['last_activity_at']}")
else:
    print(f"Failed to fetch projects: {response.status_code}")
