# 定义文件名
filename = 'file.txt'

# 读取文件内容
with open(filename, 'r') as file:
    content = file.read()

# 去除首尾空格和换行符，并按行分割内容
lines = content.strip().split('\n')

# 解析每一行，转换为元组列表
parsed_tuples = []
for line in lines:
    print(line)
    # 去除括号和空格，并按逗号分割每个元素
    elements = line.strip()[1:-1].split(',')

    # 将元素转换为元组并添加到列表中
    parsed_tuples.append((int(elements[0].strip()), elements[1].strip(), elements[2].strip()))

# 打印解析后的元组列表
print(parsed_tuples)
