import os

# 获取 exports 文件夹下的所有文件
directory = './exports'
file_list = os.listdir(directory)

# 遍历文件列表
for filename in file_list:
    if filename.endswith('.tar.gz') and filename.startswith('project_'):
        # 解析文件名中的文件ID和旧文件名
        file_id = filename.split('_')[1].split('.')[0]
        old_filename = filename.split('_')[2]

        # 构造新的文件名
        new_filename = f"{old_filename}.tar.gz"

        # 构造旧文件路径和新文件路径
        old_file_path = os.path.join(directory, filename)
        new_file_path = os.path.join(directory, new_filename)

        # 使用 os 模块的 rename 函数重命名文件
        try:
            os.rename(old_file_path, new_file_path)
            print(f"File renamed from '{old_file_path}' to '{new_file_path}'")
        except OSError as e:
            print(f"Failed to rename file '{old_file_path}': {e}")
