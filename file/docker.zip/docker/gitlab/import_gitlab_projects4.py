import os
import requests
import time

# 配置 GitLab 实例 URL 和访问令牌
GITLAB_URL = "http://gitlab.wahaha.com.cn:8090"
ACCESS_TOKEN = "your_access_token"
NAMESPACE = "hongsheng"  # 指定目标路径中的命名空间
ACCESS_TOKEN = "qqcbikFL1ALfWmyw6u-6"

# 设置请求头
headers = {
    "PRIVATE-TOKEN": ACCESS_TOKEN
}


# 获取本地项目文件列表
def get_local_project_files(directory):
    return [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.tar.gz')]


# 上传项目文件
def upload_project(file_path):
    # project_name = os.path.basename(file_path).replace('.tar.gz', '')  # 去掉文件名的 .tar.gz 后缀
    file_name = os.path.basename(file_path).replace('.tar.gz', '')  # 去掉文件名的 .tar.gz 后缀
    project_name = ''.join(c if c.isalnum() or c in ['_', '.', '-', ' '] else '_' for c in file_name)
    print(file_path,project_name)
    url = f"{GITLAB_URL}/api/v4/projects/import"
    with open(file_path, 'rb') as file:
        files = {
            'file': (os.path.basename(file_path), file, 'application/octet-stream')
        }
        data = {
            'path': f"{project_name}",
            'namespace': NAMESPACE,
            'name': project_name
        }
        print(url,headers,data)
        response = requests.post(url, headers=headers, files=files, data=data)

        if response.status_code == 201:
            project_id = response.json()['id']
            print(f"Project {file_path} uploaded with ID: {project_id}")
            return project_id
        else:
            print(f"Failed to upload project {file_path}: {response.status_code} - {response.text}")
            return None


# 检查项目导入状态
def check_import_status(project_id):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/import"
    while True:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            status = response.json().get('import_status')
            if status == 'finished':
                print(f"Project {project_id} import finished.")
                break
            elif status == 'failed':
                print(f"Project {project_id} import failed.")
                break
        else:
            print(f"Failed to check import status for project {project_id}: {response.status_code} - {response.text}")
        time.sleep(5)


# 主程序
if __name__ == "__main__":
    # 指定本地项目导出文件目录
    directory = './exports'

    project_files = get_local_project_files(directory)
    print(f"Total projects to import: {len(project_files)}")

    for file_path in project_files:
        project_id = upload_project(file_path)
        if project_id:
            check_import_status(project_id)
        time.sleep(5)  # Optional: add delay to avoid rate limiting
