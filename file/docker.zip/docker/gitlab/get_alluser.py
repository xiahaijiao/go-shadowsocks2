import requests

# 设置 GitLab API 的基本 URL 和私有访问令牌
base_url = 'https://gitlab.example.com/api/v4'
private_token = 'YOUR_PRIVATE_TOKEN'  # 替换为您的私有访问令牌
base_url = "https://gitlab.h-shgroup.com/api/v4"
private_token = "jeZWf8guKK7YBEspYbt4"

base_url = "http://gitlab.wahaha.com.cn:8090/api/v4"
private_token = "qqcbikFL1ALfWmyw6u-6"


# 构建请求头，包含私有访问令牌
headers = {'PRIVATE-TOKEN': private_token}

# 发送 GET 请求到 /users 端点获取所有用户
response = requests.get(f'{base_url}/users', headers=headers)
# https://gitlab.h-shgroup.com/api/v4/users?page=1&per_page=100

response = requests.get(f'{base_url}/users?page=1&per_page=100', headers=headers)
response = requests.get(f'{base_url}/users?page=2&per_page=100', headers=headers)

# 检查响应状态码
if response.status_code == 200:
    # 将响应转换为 JSON 格式并打印用户列表
    users = response.json()
    print(users)
    for user in users:
        print(f"ID: {user['id']}, Username: {user['username']}, Name: {user['name']}  ,email: {user['email']}")
else:
    print(f"Failed to retrieve users. Status code: {response.status_code}")
