import requests
import time

# 配置 GitLab 实例 URL 和访问令牌
GITLAB_URL = "https://gitlab.h-shgroup.com/"
ACCESS_TOKEN = "jeZWf8guKK7YBEspYbt4"
# https://gitlab.h-shgroup.com/api/v4/users?page=1&per_page=100
# https://gitlab.h-shgroup.com/api/v4/projects?page=1&per_page=100
# 设置请求头
headers = {
    "PRIVATE-TOKEN": ACCESS_TOKEN
}


# 获取所有项目
def get_all_projects():
    projects = []
    page = 1
    per_page = 100

    while True:
        url = f"{GITLAB_URL}/api/v4/projects?page={page}&per_page={per_page}"
        response = requests.get(url, headers=headers)

        if response.status_code != 200:
            print(f"Failed to retrieve projects: {response.status_code}")
            break

        data = response.json()
        if not data:
            break

        projects.extend(data)
        page += 1

    return projects


# 导出项目
def export_project(project_id):
    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/export"
    response = requests.post(url, headers=headers)

    if response.status_code == 202:
        print(f"Exporting project {project_id} started.")
    else:
        print(f"Failed to start export for project {project_id}: {response.status_code}")


# 下载导出文件
def download_export(project_id):
    while True:
        url = f"{GITLAB_URL}/api/v4/projects/{project_id}/export"
        response = requests.get(url, headers=headers)
        if response.status_code == 200 and response.json().get("export_status") == "finished":
            break
        time.sleep(5)

    url = f"{GITLAB_URL}/api/v4/projects/{project_id}/export/download"
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        with open(f"project_{project_id}.tar.gz", "wb") as file:
            file.write(response.content)
        print(f"Project {project_id} downloaded.")
    else:
        print(f"Failed to download export for project {project_id}: {response.status_code}")


# 主程序
if __name__ == "__main__":
    projects = get_all_projects()
    print(f"Total projects to export: {len(projects)}")

    for project in projects:
        project_id = project["id"]
        export_project(project_id)
        download_export(project_id)
        time.sleep(5)  # Optional: add delay to avoid rate limiting
