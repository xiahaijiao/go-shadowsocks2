import json

# 文件名
file_name = 'data.json'
file_name = 'josn1'
# file_name = 'json2'

# 读取并解析 JSON 文件
with open(file_name, 'r', encoding='utf-8') as file:
    data = json.load(file)

# 访问并打印所需字段
for item in data:
    # print(f"id: {item['id']}")
    # print(f"path: {item['path']}")
    # print(f"http_url_to_repo: {item['http_url_to_repo']}")
    print(f"id: {item['id']},  name: {item['name']} ,description: {item['description']} ,path: {item['path']}, http_url_to_repo: {item['http_url_to_repo']} ")
