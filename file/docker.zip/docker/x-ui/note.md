# 安装
```bash


bash <(curl -Ls https://raw.githubusercontent.com/vaxilu/x-ui/master/install.sh)


cd /root/
rm x-ui/ /usr/local/x-ui/ /usr/bin/x-ui -rf
tar zxvf x-ui-linux-amd64.tar.gz
chmod +x x-ui/x-ui x-ui/bin/xray-linux-* x-ui/x-ui.sh
cp x-ui/x-ui.sh /usr/bin/x-ui
cp -f x-ui/x-ui.service /etc/systemd/system/
mv x-ui/ /usr/local/
systemctl daemon-reload
systemctl enable x-ui
systemctl restart x-ui


wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/x-ui.tar.gz


```

cf端口


    80
    8080
    8880
    2052
    2082
    2086
    2095



    443
    2053
    2083
    2087
    2096
    8443
