img="yidadaa/chatgpt-next-web"
img="xiahaijiao/h-shgroup:chatgpt-next-web"
docker stop gpt
docker rm gpt
docker run --name=gpt  -d -p 10089:3000 \
   -e OPENAI_API_KEY="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" \
   -e CODE="hxtEZuBRX6X" \
   $img