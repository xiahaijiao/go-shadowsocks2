#!/usr/bin/env sage
import sys
from sage.all import *

start_num = 13
count = 1000

end_num = start_num + count

index_num = 0
while start_num < end_num:
    p = start_num
    if is_prime(p):
        n = EllipticCurve(GF(p), [0, 7]).order()
        if is_prime(n):
            pass
            p_1=factor(p-1)
            n_1=factor(n-1)
            print("p=",p, ",n=",n, "; p-1=",p_1," ,n_1=",n_1)

    start_num = start_num + 1

