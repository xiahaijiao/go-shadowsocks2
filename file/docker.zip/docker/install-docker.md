hk-windows
1|iD-U&Si&D?#?H
usa-windows
HhKlZTSg0t1=BzJ



#lightsail
vi  /etc/ssh/sshd_config
66 PasswordAuthentication yes
41 PermitRootLogin yes

systemctl restart sshd
sudo passwd root
OdsatsCrxTebrZLo3z6GG85Io0Fnij0j
OdsatsCrxTebrZLo#


wget https://github.com/xiahaijiao/jkd/raw/refs/heads/main/file/docker.zip


wget https://raw.githubusercontent.com/xiahaijiao/go-shadowsocks2/master/file/iftop.zip
wget https://raw.githubusercontent.com/xiahaijiao/go-shadowsocks2/master/file/docker.zip
wget https://github.com/xiahaijiao/go-shadowsocks2/blob/master/file/find_n_p_random.zip


#lightsail

yum install -y yum-utils wget telnet net-tools zip tree  java-1.8.0  nginx docker 
service docker start
systemctl enable docker
curl -L "https://github.com/docker/compose/releases/download/v2.20.3/docker-compose-linux-x86_64" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
docker version
docker-compose --version

#redhat

yum install -y yum-utils wget telnet net-tools zip tree  java-1.8.0  nginx
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum install --allowerasing -y docker-ce docker-ce-cli containerd.io
service docker start
systemctl enable docker
#curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
curl -L "https://github.com/docker/compose/releases/download/v2.20.3/docker-compose-linux-x86_64" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
docker version
docker-compose --version




hostnamectl set-hostname your_hostname

yum install -y java-1.8.0


--------- docker分组
cat /etc/group |grep docker
 ll /var/run/docker.sock

gpasswd -a ec2-user docker
id
newgrp docker


-------设置时间 
vi /etc/profile
TZ='Asia/Shanghai'; export TZ
source /etc/profile
source ~/.bashrc
echo "set mouse-=a" >> ~/.vimrc
echo "set paste" >> ~/.vimrc
echo "set background=dark" >> ~/.vimrc
echo "colorscheme desert " >> ~/.vimrc

cat << eof >> ~/.vimrc
set mouse-=a
set paste
#syntax enable
set background=dark  " 如果您使用的是深色主题
colorscheme desert   " 更换主题，您可以选择其他颜色方案

eof


# :set paste          #vim禁止缩进

date
cat << eof >> /etc/profile
TZ='Asia/Shanghai'; export TZ
eof
source /etc/profile
date

#容器内设置时区
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime

cat << eof >> /etc/environment
LC_TIME="zh_CN.UTF-8"
eof

localectl set-locale LC_TIME=en_GB.UTF-8


----------ssh
vi  /etc/ssh/sshd_config
40 PermitRootLogin yes          ;34
65 PasswordAuthentication yes   ;58
 
systemctl restart sshd

sudo passwd root
OdsatsCrxTebrZLo3z6GG85Io0Fnij0j



---------规划端口
10080-10099 开放端口
54321
1001

10086 10087 v2ray
10088 firefox
10089 10090 gpt


22,只允许特定网段访问
	39.170.59.0/24
手机ip 211.90.236.216 
80 443 开放



10080-10099,54321,1001,80,443,9100,3000,9090
0.0.0.0/0
39.170.59.0/24

---------- 安装rpm包
wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/iftop.zip
wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/docker.zip

wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/docker.tar.gz



------------debian
apt install -y  curl   wget telnet net-tools zip tree  openjdk-11-jdk
apt-get install -y vnstat  nginx iftop

  yum install --downloadonly --downloaddir=./ vnstat   iftop curl   wget telnet net-tools zip tree 

curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/debian $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
apt update
apt install -y apt-transport-https ca-certificates curl gnupg-agent software-properties-common wget telnet net-tools zip tree docker-ce docker-ce-cli containerd.io  openjdk-11-jdk
curl -SL https://github.com/docker/compose/releases/download/v2.19.0/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
docker version
docker-compose --version
systemctl status docker


apt-get install openjdk-11-jdk



apt-get remove -y --purge man-db
apt-get install -y vnstat  nginx iftop
systemctl start vnstat
systemctl status vnstat
systemctl enable vnstat


cat <<eof >> ~/.bashrc
alias ll='ls -l --color=auto'
alias grep='grep --color'
eof
source ~/.bashrc

# mvn 环境变量
export MAVEN_HOME=/var/jenkins_home/apache-maven-3.9.0
export PATH=${PATH}:${MAVEN_HOME}/bin

-----------查看版本
cat /proc/version 
uname -a 
cat /etc/issue
cat /etc/redhat-release
cat /etc/os-release
cat /etc/debian_version

#debian设置中文
1.安装语言包
 apt-get install language-pack-zh
2.设置
    dpkg-reconfigure locales
    在弹出的界面中，使用上下箭头键选择 zh_CN.UTF-8，然后按空格键选中。最后，按下回车键确认选择。
3.设置默认字符集
编辑 /etc/default/locale 文件，确保文件中包含以下行：
    LANG="zh_CN.UTF-8"
    LC_MESSAGES="zh_CN.UTF-8"
    LC_ALL="zh_CN.UTF-8"
4.重启生效
 reboot
5.检查
    locale
    确保输出中包含 zh_CN.UTF-8，表示你的系统已成功设置为中文编码。

------debian
wget http://aws0628.xiahaijiao.eu.org:81/node_exporter-1.5.0.linux-amd64.zip
apt install -y  curl   wget telnet net-tools zip tree  openjdk-11-jdk
apt-get install -y vnstat  nginx iftop
apt install docker.io   -y
apt-cache search docker


cat <<EOF >./vnstat.sh
vnstat -d
EOF
chmod +x ./vnstat.sh
./vnstat.sh


---------- alpine
apk add bash


--------ip

cat <<EOF >./ip.sh
 curl https://ip38.com |grep 您的iP地址是
 curl https://ipinfo.io/
EOF
chmod +x ./ip.sh
./ip.sh

cat << eof >> ~/.vimrc
set mouse-=a
set paste
#syntax enable
set background=dark  " 如果您使用的是深色主题
colorscheme desert   " 更换主题，您可以选择其他颜色方案
eof



cat <<EOF >./hostname.sh
 hostnamectl set-hostname instance-taiwan
EOF
chmod +x ./hostname.sh


