
yum install -y yum-utils wget telnet net-tools  zip
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum install --allowerasing -y docker-ce docker-ce-cli containerd.io
service docker start
systemctl enable docker
#curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
curl -SL https://github.com/docker/compose/releases/download/v2.19.0/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
docker version
docker-compose --version


ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
docker-compose --version

hostnamectl set-hostname your_hostname


--------- docker分组
cat /etc/group |grep docker
 ll /var/run/docker.sock
 gpasswd -a ec2-user docker
 id
newgrp docker

-------设置时间
vi /etc/profile
TZ='Asia/Shanghai'; export TZ
source /etc/profile


----------ssh
vi  /etc/ssh/sshd_config
40 PermitRootLogin yes
65 PasswordAuthentication yes

systemctl restart sshd

---------规划端口
10080-10099 开放端口

10086 10087 v2ray
10088 firefox
10089 10090 gpt


22,只允许特定网段访问
80 443 开放


---------- 安装rpm包
 wget https://github.com/xiahaijiao/go-shadowsocks2/raw/master/file/iftop.zip

