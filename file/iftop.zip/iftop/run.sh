rpm -ivh *.rpm
systemctl start vnstat
systemctl status vnstat
systemctl enable vnstat



yum install nc
yum install libpcap
