rpm -ivh *.rpm
systemctl start vnstat
systemctl status vnstat
systemctl enable vnstat
