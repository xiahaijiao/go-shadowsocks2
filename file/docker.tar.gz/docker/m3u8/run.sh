
touch m3u8/playlists/list.txt
ln -s m3u8/playlists/list.txt list.txt

docker-compose up -d
