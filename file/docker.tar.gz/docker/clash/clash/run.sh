nohup /usr/bin/clash -d /etc/clash >/etc/clash/log 2>&1 &
