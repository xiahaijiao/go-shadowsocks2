
unset http_proxy
unset https_proxy
unset HTTP_PROXY
