nohup ./main.sh ecc-order.py > ./log  2>&1 &
