
#/home/sage/sage/local/var/lib/sage/venv-python3.10.5/bin/python3 py.py
/home/sage/sage/local/var/lib/sage/venv-python3.10.5/bin/python3 -u $1
