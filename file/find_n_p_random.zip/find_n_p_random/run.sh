
app=$1
nohup ./main.sh $app > ./log-$app.log  2>&1 &

