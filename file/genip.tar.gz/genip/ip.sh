 curl https://ip38.com |grep 您的iP地址是
 curl https://ipinfo.io/
