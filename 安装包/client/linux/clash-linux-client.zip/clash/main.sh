./clash-linux-amd64-v1.17.0 -d clash
