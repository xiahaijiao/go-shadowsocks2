ps -ef | grep clash
