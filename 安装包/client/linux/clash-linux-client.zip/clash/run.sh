nohup sh main.sh >> ./log 2>&1 &

