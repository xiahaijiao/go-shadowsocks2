ps -ef |grep v2ray
