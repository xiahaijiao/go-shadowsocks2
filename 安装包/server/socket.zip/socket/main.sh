./shadowsocks2-linux -s 'ss://AEAD_CHACHA20_POLY1305:123456@:10086' -verbose

