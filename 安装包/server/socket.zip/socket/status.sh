ps -ef | grep shadowsocks2
