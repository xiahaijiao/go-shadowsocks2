/opt/socket/shadowsocks2 -s 'ss://AEAD_CHACHA20_POLY1305:123456@:10086' -verbose

