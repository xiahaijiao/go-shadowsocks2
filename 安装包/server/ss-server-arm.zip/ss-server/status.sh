ps -ef | grep shadowsocks2-linux-arm64 
