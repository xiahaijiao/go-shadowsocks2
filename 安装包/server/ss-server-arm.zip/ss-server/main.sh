socket_pass=123456
./shadowsocks2-linux-arm64 -s ss://AEAD_CHACHA20_POLY1305:$socket_pass@:10086 -verbose

